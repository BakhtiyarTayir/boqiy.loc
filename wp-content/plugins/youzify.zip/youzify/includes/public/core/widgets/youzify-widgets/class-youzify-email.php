<?php

class Youzify_Profile_Email_Info_Box_Widget extends Youzify_Profile_Info_Box_Widget {

}