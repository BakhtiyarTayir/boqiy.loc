<?php

class Youzify_Profile_User_Badges_Widget {

    /**
     * Widget Content.
     */
    function widget() {
        do_action( 'youzify_user_badges_widget_content' );
    }

}