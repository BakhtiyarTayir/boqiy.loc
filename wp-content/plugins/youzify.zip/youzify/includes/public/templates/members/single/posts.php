<?php

echo 'hamdolah';