<?php
echo "hamdolah";