<?php

/**
 * Class WPDesk_Flexible_Shipping_Send_Shipment_Exception
 */
class WPDesk_Flexible_Shipping_Label_Not_Available_Exception extends RuntimeException {
}
