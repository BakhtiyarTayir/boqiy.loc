<?php

/**
 * .
 */
class WPDesk_Flexible_Shipping_Unable_To_Create_Tmp_File_Exception extends RuntimeException {
}
