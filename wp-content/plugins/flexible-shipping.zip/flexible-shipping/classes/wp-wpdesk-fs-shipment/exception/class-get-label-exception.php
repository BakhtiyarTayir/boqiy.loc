<?php

/**
 * Class WPDesk_Flexible_Shipping_Send_Shipment_Exception
 */
class WPDesk_Flexible_Shipping_Get_Label_Exception extends RuntimeException {
}
