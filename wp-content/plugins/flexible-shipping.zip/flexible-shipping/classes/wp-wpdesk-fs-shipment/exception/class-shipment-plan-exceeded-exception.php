<?php

/**
 * Class WPDesk_Flexible_Shipping_Send_Shipment_Exception
 */
class WPDesk_Flexible_Shipping_Shipment_Plan_Exceeded_Exception extends RuntimeException {
}
