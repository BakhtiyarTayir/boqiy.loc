<?php

/**
 * Import rules from CSV.
 */
class WPDesk_Flexible_Shipping_Csv_Importer_Exception extends RuntimeException {
}
