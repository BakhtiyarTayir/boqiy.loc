<style type="text/css" media="screen">
	#adminmenu #toplevel_page_flexible-shipping-menu a div.wp-menu-image::before {
		font-family: WooCommerce !important;
		content: '\e019';
	}

	.toplevel_page_flexible-shipping-menu #wpdesk_tracker_notice {
		margin: 10px 20px 0 2px;
	}

	.fs-connect__inner-container {
		background-color: #FFF;
		margin-bottom: 20px;
	}
</style>