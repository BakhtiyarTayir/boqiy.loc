[![pipeline status](https://gitlab.com/wpdesk/flexible-shipping/badges/master/pipeline.svg)](https://gitlab.com/wpdesk/flexible-shipping/commits/master)
Integration: [![coverage report](https://gitlab.com/wpdesk/flexible-shipping/badges/master/coverage.svg?job=integration+test+lastest+coverage)](https://gitlab.com/wpdesk/flexible-shipping/commits/master)
Unit [![coverage report](https://gitlab.com/wpdesk/flexible-shipping/badges/master/coverage.svg?job=unit+test+lastest+coverage)](https://gitlab.com/wpdesk/flexible-shipping/commits/master)

Flexible Shipping Plugin
========================
