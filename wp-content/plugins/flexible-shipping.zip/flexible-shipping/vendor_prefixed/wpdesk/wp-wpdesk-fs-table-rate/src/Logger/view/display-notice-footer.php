<?php

namespace FSVendor;

/**
 *
 */
?><br/><button class="small flexible-shipping-log-clipboard-all"><?php 
echo \esc_html(\__('Copy all data', 'flexible-shipping'));
?></button><?php 
