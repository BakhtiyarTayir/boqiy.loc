<?php

namespace FSVendor\WPDesk\Persistence;

/**
 * Class ElementNotExistsException
 *
 * @package WPDesk\Persistence
 */
class ElementNotExistsException extends \RuntimeException
{
}
