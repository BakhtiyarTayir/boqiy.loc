<?php

namespace FSVendor;

if (!\defined('ABSPATH')) {
    exit;
}
?>
<div id="wpdesk_tracker_notice" class="updated notice wpdesk_tracker_notice">
	<p><?php 
\_e('You successfully opted out of collecting usage data by WP Desk. If you change your mind, you can always opt in later in the plugin\'s quick links.', 'flexible-shipping');
?></p>
</div>
<?php 
