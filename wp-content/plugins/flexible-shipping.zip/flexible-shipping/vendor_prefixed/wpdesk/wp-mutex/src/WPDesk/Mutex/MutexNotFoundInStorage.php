<?php

namespace FSVendor\WPDesk\Mutex;

class MutexNotFoundInStorage extends \RuntimeException
{
}
