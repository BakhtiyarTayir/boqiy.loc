<?php

namespace FSVendor;

include './WPDesk/Mutex/Mutex.php';
include './WPDesk/Mutex/MutexNotFoundInStorage.php';
include './WPDesk/Mutex/MutexStorage.php';
include './WPDesk/Mutex/StaticMutexStorage.php';
include './WPDesk/Mutex/WordpressMySQLLockMutex.php';
include './WPDesk/Mutex/WordpressPostMutex.php';
include './WPDesk/Mutex/WordpressWpdb.php';
include './WPDesk/functions.php';
