<?php

namespace FSVendor\WPDesk\View\Resolver\Exception;

class CanNotResolve extends \RuntimeException
{
}
